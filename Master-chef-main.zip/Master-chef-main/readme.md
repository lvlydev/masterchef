#to learn how to make a maggi in 2 minutes 
this is for people who wanna learn to make a maggie 
this is a recipe of a ready made noodeles which can me done in 2/3 mins 

check out all files to learn how to make a maggie !