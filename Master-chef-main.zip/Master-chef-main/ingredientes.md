The ingredients needed for this recipe are as followes 
A 1/2 cup of water for one person 
maggie packet 
vegetable (optional)
maggie masala 
oil(if adding vegetable )

check out other file to learn how to make it 