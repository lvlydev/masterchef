This is the recipe to how you make a maggie

take your vessile and add 1/2 cup of water (for 1 cake of maggie)
-wait for 2 mins 
now add maggie masala 
after adding the masala add the maggie cake by breaking it vertically
Now stir the maggie proprely  
now wait for 10 mins.....

Now your maggie is ready to serve ..... :)